namespace DsiVendas.Models
{
  public class AppUser
  {
    public string Username { get; set; }
    public string Password { get; set; }
    public string Profile { get; set; }
  }
}